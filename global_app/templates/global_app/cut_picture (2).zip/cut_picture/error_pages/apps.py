from django.apps import AppConfig


class ErrorPagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'error_pages'
