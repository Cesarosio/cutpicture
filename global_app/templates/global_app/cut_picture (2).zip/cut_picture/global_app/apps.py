from django.apps import AppConfig


class GlobalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'global_app'
